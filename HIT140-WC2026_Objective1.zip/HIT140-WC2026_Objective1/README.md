# FIFA World Cup 2026 — Objective 1

**Darwin Group 46**  ·  Assessment 2, due 10 September 2026, 14:00 ACST

See `RECORDING_PLAN.md` for the segment split, timings and submission checklist.

| Member | Student ID | Task owned |
|---|---|---|
| Angel Shahi | s400420 | 1 — Goal timing |
| Nishant Shrestha | s400342 | 2 — Team playing style |
| Sabraham Shrestha | s404389 | 3 — Attacking output by position |
| Akash Singh | s401643 | 4 — Schedule recovery |

---

## The four analytic tasks

| # | Owner | Focal point | Response variable | Unit of analysis | n | Test |
|---|---|---|---|---|---|---|
| 1 | Angel Shahi | Goal timing — **when** a goal arrives | Minute of the goal | Goal event | 300 | **One-sample** *t* against 45.5 |
| 2 | Nishant Shrestha | Team playing style — **how** a team plays | Possession share (%) | Nation | 48 | Two-sample *t* |
| 3 | Sabraham Shrestha | Attacking output — **who** creates goals | Goals + assists per 90 min | Player | 286 | Two-sample *t* |
| 4 | Akash Singh | Schedule recovery — **how often** they play | Days between matches | Recovery interval | 160 | Two-sample *t* |

Four different constructs, four different response variables, four different units of
analysis. Every task covers the six required skills: analytic question, data wrangling,
data preparation and sampling, descriptive statistics, confidence interval, and a *t*-test.

### Results

| # | Mean | 95% CI (z-interval) | *t* | df | p | Decision |
|---|---|---|---|---|---|---|
| 1 | 52.65 min | [49.58, 55.73] | 4.56 | 299 | < .001 | Reject H₀ |
| 2 | 48.63 % | [45.95, 51.30] | 2.63 | 15 | .009 | Reject H₀ |
| 3 | 0.34 per 90 | [0.30, 0.39] | 4.42 | 72 | < .001 | Reject H₀ |
| 4 | 5.29 days | [5.14, 5.44] | −4.12 | 63 | < .001 | Reject H₀ |

The interval in each row is the Week 3 z-interval for that task's own mean —
x̄ ± z*·s/√n with z* = 1.960 — not for the difference between groups.

The four focal points were chosen after exploring the verified data, so running four
tests raises the chance that at least one rejection is a false positive. HIT140 has
not covered a correction for that, so the fact is **stated rather than silently
corrected or silently ignored**. Every one of the four is decided well below α = 0.05.

## Method scope

The brief requires the skills of **Weeks 1 to 5**. Every procedure used here comes from that range and nothing beyond it:

| Week | What is used |
|---|---|
| 2 | mean, median, mode, range, quartiles, IQR, the **1.5 × IQR outlier rule**, variance, standard deviation, skewness, histogram |
| 3 | Central Limit Theorem, z* (1.645 / 1.960 / 2.576), **CI = x̄ ± z*·s/√n** with its n ≥ 30 condition, CI for a proportion |
| 4 | the **four-step process** (State, Plan, Solve, Conclude), the t-distribution, df = n − 1, the one-sample *t*, the two-sample independent *t* with separate variances and the conservative **df = min(n₁,n₂) − 1**, α = 0.05, APA reporting |
| 5 | pandas joins and concat, missing-data handling, feature construction |

Techniques outside that range are deliberately absent: bootstrap intervals,
Levene's test, Welch degrees of freedom, pooled variance, Mann–Whitney, Wilcoxon,
Shapiro–Wilk, Cohen's *d*, statistical power, the Bonferroni correction — and
correlation, which is Week 6. Section 4 of `wc2026_analysis.py` names each one at the point where it
is declined. Robustness is shown the way the unit allows — by re-running the same
*t*-test after the Week 2 IQR rule removes the flagged outliers.

---

## What is in this folder

| Path | What it is |
|---|---|
| `wc2026_analysis.py` | The analysis. One self-contained script: acquisition, 28 verification checks, wrangling, statistics toolkit, the four tasks, the figures. |
| `WC2026_Analysis.ipynb` | The analysis as a notebook, figures inline, outputs saved. |
| `WC2026_Dataset.xlsx` | The dataset as an 11-sheet workbook. Monochrome by design. |
| `dataset/*.csv` | The six data tables, plus the verification log. |
| `WC2026_Presentation.pptx` | The deck: 12 presented slides in four recorded segments, plus a 5-slide appendix. |
| `RECORDING_PLAN.md` | Who presents which slide, timings, and exactly what to submit. |
| `PROVENANCE.md` | Where every number came from, the 28 checks, what the validation caught. |
| `data/fbref/` | The 23 tables exported from FBref's 2026 World Cup pages. |
| `data/raw/` | The cached open-archive downloads, so the script runs offline. |
| `outputs/figures/` | Every chart, regenerated on each run. |
| `outputs/tables/` | Result tables and `deck_data.json`. |
| `requirements.txt` | The packages the script needs. |
| `view_figures.py` | Opens the saved figures in Python windows (`--grid` for a contact sheet). |
| `build_dataset_workbook.py` | Rebuilds the workbook from the script's outputs. |
| `build_notebook.py` | Rebuilds and re-executes the notebook. |
| `build_deck.js` | Rebuilds the deck. Every number on every slide is read from `deck_data.json` — nothing is typed by hand. |

### The dataset is exactly what the four tasks read

Six tables, no more. Three frames the pipeline builds internally are deliberately
**not** exported, because no task uses them: `teams` (every column of it also
appears in `squad_profile`), `referees`, and `match_context`.

| Table | Rows | Serves |
|---|---|---|
| `goals.csv` | 308 | Task 1 — minute of each goal event |
| `squad_profile.csv` | 48 | Task 2 — possession share per nation |
| `players.csv` | 1,039 | Task 3 — goal involvements per 90 |
| `rest.csv` | 160 | Task 4 — the recovery intervals |
| `matches.csv` | 104 | Task 4 — match dates and stages |
| `team_match.csv` | 208 | Task 4 — the paired winner-vs-loser analysis |
| `source_verification.csv` | 28 | the verification log |

## Data sources

**FBref is our primary source.** Its 2026 World Cup tables carry Tasks 2, 3 and 4
outright — squad possession, the player tables, and the fixture list with dates.
They were taken from the site's own *Share & Export → Get table as CSV* control
(23 tables, in `data/fbref/`).

FBref publishes goal times only inside individual match reports, not in any
exportable table, so the 308 goal events with their minutes come from an open
archive. **Task 1 alone depends on it.** A third archive is used for verification
only — no task reads it.

| | Source | Role | Used by |
|---|---|---|---|
| 1 | **FBref, 2026 World Cup** (`fbref.com`) | primary — players, squads, fixtures | Tasks 2, 3, 4 |
| 2 | `openfootball/worldcup.json` | the 308 goal events and their minutes | Task 1 |
| 3 | `martj42/international_results` | verification only | no task |

Three sources maintained by different people from different upstreams agree on all
104 scorelines and all 308 goal events. That agreement is only possible if all three
describe the same tournament, so every FBref figure is corroborated before it is
analysed. Using one source alone would have left nothing to check it against.

## Running it

Python 3.10 or newer. From inside this folder:

```bash
pip install -r requirements.txt

python3 wc2026_analysis.py --validate   # 1. fast check: the 28 source checks only (~10 s)
python3 wc2026_analysis.py              # 2. full run: checks, four tasks, figures (~40 s)
python3 build_dataset_workbook.py       # 3. rebuild the Excel workbook
node build_deck.js                      # 4. rebuild the deck (optional; needs `npm i pptxgenjs`)
```

### Google Colab

The notebook's first cell handles Colab. Open
[colab.research.google.com](https://colab.research.google.com) → **Upload** →
choose `WC2026_Analysis.ipynb`, then run **cell 0**: it asks you to upload
`WC2026_Objective1.zip`, unpacks it and moves into the project folder. Then
*Runtime → Run all*. There is a commented-out Google Drive option in the same cell
if you would rather keep the zip in Drive than upload it each session.

Cell 0 does nothing when the notebook is not on Colab, so the same file works in
both places. Verified against pandas 2.2 (Colab's version) as well as pandas 3 —
identical results.

### The notebook

`WC2026_Analysis.ipynb` walks through all four tasks with **the figures inline** and
every table printed. It is saved with its outputs already in it, so it can be read
without running anything — open it in VS Code (install the *Jupyter* extension) or
with `jupyter notebook`. To re-run it, use **Run All**.

The notebook imports `wc2026_analysis.py` rather than repeating any of it, so its
numbers, the workbook's and the deck's cannot drift apart.

To look at the charts on screen rather than as saved files:

```bash
python3 wc2026_analysis.py --show   # run the analysis AND open each figure in a window
python3 view_figures.py             # open the already-saved figures, one window each
python3 view_figures.py --grid      # all eleven on a single contact sheet
python3 view_figures.py task2       # only the figures for one task
```

On Windows use `py` instead of `python3`.

`data/raw/` already contains the downloaded sources, so **step 1 and 2 work with no
internet connection**. Add `--refresh` to re-download them from GitHub instead of
using the cached copies.

### What a good run looks like

```
  -> 28/28 checks passed
...
 task             owner        ...    t     df  p_value   decision_alpha_05
    1  Angel Shahi        ...  4.560076 299.0 0.000007          Reject H0
    2  Nishant Shrestha   ...  2.633363  15.0 0.009403          Reject H0
    3  Sabraham Shrestha  ...  4.422373  72.0 0.000017          Reject H0
    4  Akash Singh        ... -4.120329  63.0 0.000056          Reject H0
```

Exit code 0 and `28/28 checks passed` means everything reproduced. The script
**refuses to run** if any check fails: a failing check means the sources have drifted
apart, and analysing data that has drifted is worse than not analysing it.

Running the analysis rewrites `outputs/figures/`, `outputs/tables/master_results.csv`
and `outputs/tables/deck_data.json`. The deck reads every number it prints from that
JSON, so nothing on a slide is typed by hand.

### Tested versions

Identical results on both:

| | pandas | numpy | scipy | matplotlib | openpyxl |
|---|---|---|---|---|---|
| newer | 3.0.2 | 2.4.4 | 1.17.1 | 3.10.9 | 3.1.5 |
| older | 2.2.3 | 2.2.6 | 1.17.1 | 3.10.9 | 3.1.5 |

## Checking the data yourself

Open `WC2026_Dataset.xlsx` → **Live_Checks**. Thirty-one formulas recompute the
integrity logic and each task's group sizes and means inside the workbook. Change a
scoreline on the **Matches** sheet and checks 4 and 6 fail immediately. That is the
point of the sheet.
